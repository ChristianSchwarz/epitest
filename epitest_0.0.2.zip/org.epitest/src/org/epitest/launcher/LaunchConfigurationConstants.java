package org.epitest.launcher;

public class LaunchConfigurationConstants {

	public static final String ATTR_TEST_CONTAINER = "org.epitest.testContainer";
	public static final String ATTR_TEST_METHOD_NAME = "org.epitest.methodName";

}
